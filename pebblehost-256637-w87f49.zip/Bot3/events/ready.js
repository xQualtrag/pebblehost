const Parser = require('rss-parser');
const parser = new Parser();
const chalk = require('chalk');
const fs = require('node:fs');
const config = require('../config.json');

module.exports = {
    name: 'ready',
    once: true,
    execute(client) {
        console.log(chalk.green('[Ready]') + ` Logged in as ${client.user.tag}!`);    
        const guild = client.guilds.cache.get(config.guild_id);
        setInterval(async () => {
            let config = fs.readFileSync(__dirname + '/../config.json', 'utf8');
            config = JSON.parse(config);
            const channel = guild.channels.cache.get(config.new_video_channel_id);
            const data = await parser.parseURL(`https://www.youtube.com/feeds/videos.xml?channel_id=${config.yt_channel_id}`);
            const latestVideoId = data.items[0].id.split(':').pop();
            const oldLatestVideoId = config.video_id;
            if (latestVideoId !== oldLatestVideoId) {
                console.log(chalk.green('[New Video]') + ' A new video has been uploaded! ' + data.items[0].title);
                config.video_id = latestVideoId;
                fs.writeFileSync('./config.json', JSON.stringify(config, null, 4));
                channel.send(`@everyone ${data.title} has uploaded ${data.items[0].title}, Check it out ${data.items[0].link}`);
            }   
        }, 5000);
        setInterval(async () => {
            let config = fs.readFileSync(__dirname + '/../config.json', 'utf8');
            config = JSON.parse(config);
            let scheduled = fs.readFileSync(__dirname + '/../scheduled.json', 'utf8');
            scheduled = JSON.parse(scheduled);
            const guild = client.guilds.cache.get(config.guild_id);
            const now = new Date().getTime();
            for (const scheduledMessage of scheduled) {
                if (scheduledMessage.time < now) {
                const sChannel = await guild.channels.cache.get(scheduledMessage.channel);
                const member = await guild.members.fetch(scheduledMessage.id);
                const webhooks = await guild.fetchWebhooks();
                console.log(chalk.green('[Scheduled Message]') + ' Sending scheduled message by ' + member.user.username);
                let webhook = webhooks.filter(w => w.name == member.user.username).first();
                if (!webhook) {
                    webhook = await sChannel.createWebhook({
                        name: member.user.username,
                        avatar: member.user.displayAvatarURL({ dynamic: true }),
                        channel: sChannel,
                    })
                }
                await webhook.send(scheduledMessage.message);
                scheduled.splice(scheduled.indexOf(scheduledMessage), 1);
                fs.writeFileSync('./scheduled.json', JSON.stringify(scheduled, null, 4));
                }
            }
        }, 2000)
        setInterval(async () => {
            let muted = fs.readFileSync(__dirname + '/../muted.json', 'utf8');
            muted = JSON.parse(muted);
            const now = new Date().getTime();
            for (const mutedUser of muted) {
                if (mutedUser.time < now) {
                    const member = await guild.members.fetch(mutedUser.id);
                    console.log(chalk.green('[Muted]') + ' Unmuting user ' + member.user.username);
                    member.roles.remove(config.muted_role_id);
                    muted.splice(muted.indexOf(mutedUser), 1);
                    fs.writeFileSync('./muted.json', JSON.stringify(muted, null, 4));
                }
            }
        })
    }
}
