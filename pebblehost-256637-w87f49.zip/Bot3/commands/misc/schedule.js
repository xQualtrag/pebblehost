const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('node:fs');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('schedule')
        .setDescription('Schedule a message to be sent at a certain time')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addStringOption(option => option.setName('message').setDescription('The message to send').setRequired(true))
        .addStringOption(option => option.setName('time').setDescription('Date and time to send the message in format YYYY-MM-DD, hh:mm').setRequired(true))
        .addChannelOption(option => option.setName('channel').setDescription('The channel to send the message in').setRequired(false)),
    async execute(interaction) {
        let scheduled = fs.readFileSync(__dirname + '/../../scheduled.json', 'utf8');
        scheduled = JSON.parse(scheduled);  
        const guild = interaction.guild;
        const message = interaction.options.getString('message');
        const Time = interaction.options.getString('time');
        const cTime = new Date().getTime();
        const channel = interaction.options.getChannel('channel') || interaction.channel;
        const sTime = new Date(Time).getTime();
        if (validTime(Time) == false) {
            return interaction.reply({ content: 'Invalid time, please use time format YYYY-MM-DD, hh:mm', ephemeral: true })
        }
        if (sTime < cTime) { 
            return interaction.reply({ content: 'The time you entered is in the past', ephemeral: true });
        }
        if (message.length > 2000) {
            return interaction.reply({ content: 'Message is too long', ephemeral: true });
        }
        let t = new Date(sTime);
        t = t.toUTCString();
        let scheduledMessage = {
            id: interaction.member.id,
            message: message,
            time: sTime,
            channel: channel.id
        }
        scheduled.push(scheduledMessage);
        fs.writeFileSync(__dirname + '/../../scheduled.json', JSON.stringify(scheduled, null, 4));
        interaction.reply({ content: `Message scheduled for ${time(sTime / 1000)}` });
    }
}

function validTime(t) {
    let a = t.split(',')
    let b = a[0].split('-')
    let c = a[1].split(':') 
    y = parseInt(b[0])
    m = parseInt(b[1])
    d = parseInt(b[2])
    h = parseInt(c[0])
    min = parseInt(c[1])
    if (y > 2022 || m > 12 || d > 31) {
        return false
    } else if (h > 23 || min > 59) {
        return false
    } else {
        return true
    }
}