const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ping')
        .setDescription('Send bot\'s ping'),
    async execute(interaction) {
        ping = interaction.client.ws.ping   
        await interaction.reply('```The bot ping is '+ ping +' ms```');
    }
}