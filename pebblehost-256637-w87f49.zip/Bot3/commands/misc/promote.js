const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const roles = require('../../roles.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('promote')
        .setDescription('Promote a user')
        .addUserOption(option => option.setName('member').setDescription('The user to promote').setRequired(true))
        .addStringOption(option => option.setName('role').setDescription('The role to promote the user to')
            .addChoices(
                { name: '👑 | Boss', value: '956628645919735808' },
                { name: '📌 | Underboss', value: '956628487505084477' },
                { name: '🎓 | Captain', value: '956628979501137940' },
                { name: '✨ | Made Woman', value: '956631378617856000' },
                { name: '✨ | Made Man', value: '956629374034133022' },
                { name: '🔥 | Helper', value: '956625735303438376'}
            ).setRequired(true)),
    async execute(interaction) { 
        const member = interaction.options.getUser('member');
        let gRole = interaction.options.getString('role');
        const role = roles.find(r => r.id === gRole);
        gRole = interaction.guild.roles.cache.get(role.id);
        const user = interaction.member;
        if (gRole.position > interaction.guild.members.me.roles.hightest) {
            return interaction.reply({ content: 'My hightest role is less than the specified role / member\'s role', ephemeral: true });
        } 
        if (gRole.position > user.roles.highest.position) {
            return interaction.reply({ content: 'Your role is less than the specified role / member\'s role', ephemeral: true });
        }
        let userRole;
        roles.forEach(r => {
            if (user.roles.cache.has(r.id)) {
                if (r.level > role.level) {
                    userRole = r;
                } 
            }
        })
        if (!userRole && !user.permissions.has(PermissionFlagsBits.ManageRoles | PermissionFlagsBits.ManageGuild | PermissionFlagsBits.Administrator)) {
            return await interaction.reply({ content:'Your role is less than the specified role / member\'s role', ephemeral: true });
        }
        await interaction.guild.members.fetch(member.id);
        await interaction.guild.members.cache.get(member.id).roles.add(role.id);
        await interaction.reply({ content: `Promoted ${member} to ${role.name}`, ephemeral: true });
    }
}
