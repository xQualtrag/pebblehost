const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { owner_ids } = require('../../config.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setusername')
        .setDescription('Set the bot\'s username')
        .addStringOption(option => option.setName('username').setDescription('The username to set').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    async execute(interaction) {
        if (!owner_ids.includes(interaction.user.id)) {
            return interaction.reply({ content: 'You are not the bot owner', ephemeral: true });
        }
        const username = interaction.options.getString('username');
        interaction.client.user.setUsername(username);
        interaction.reply('Successfully set the bot\'s username');
    }
}