const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { owner_ids } = require('../../config.json');
const scheduled = require('../../scheduled.json');
const muted = require('../../muted.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('stats')
        .setDescription('Send bot\'s stats')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    async execute(interaction) {
        if (!owner_ids.includes(interaction.user.id)) {
            return interaction.reply({ content: 'You are not the bot owner', ephemeral: true });
        }
        const stats = {
            commands: interaction.client.commands.size,
            memory: process.memoryUsage().heapUsed / 1024 / 1024,
            ping: interaction.client.ws.ping,
            uptime: mstoTime(interaction.client.uptime),
            scheduled: scheduled.length,
            muted: muted.length,
            discordjs: require('discord.js').version,
            nodejs: process.version
        }
        const embed = new EmbedBuilder()
            .setTitle('Bot stats')
            .setDescription(
                `**Commands:** ${stats.commands}\n` +
                `**Memory:** ${stats.memory.toFixed(2)} MB\n` +
                `**Ping:** ${stats.ping} ms\n` +
                `**Uptime:** ${stats.uptime}\n` +
                `**Scheduled Messages:** ${stats.scheduled}\n` +
                `**Muted:** ${stats.muted}\n` +
                `**Discord.js Version:** ${stats.discordjs}\n` +
                `**Node.js Version:** ${stats.nodejs}`
            )
            .setThumbnail(interaction.client.user.avatarURL({ format: 'png', dynamic: true, size: 1024 }))
            .setTimestamp()
            .setColor('#ffff00');
        await interaction.reply({ embeds: [embed] });
    }
}

function mstoTime(t) {
    let secs = Math.floor(t / 1000);
    let mins = Math.floor(secs / 60);
    let hours = Math.floor(mins / 60);
    let days = Math.floor(hours / 24);
    secs %= 60;
    mins %= 60;
    hours %= 24;
    let time = `${days} days, ${hours} hours, ${mins} minutes, ${secs} seconds`;
    let a = time.split(', ');
    let b = a.filter(x => x.startsWith('0'))
    b.forEach(x => a.splice(a.indexOf(x), 1));
    return a.join(', ');
}   