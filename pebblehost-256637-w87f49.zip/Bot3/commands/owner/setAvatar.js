const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { owner_ids } = require('../../config.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setavatar')
        .setDescription('Set the bot\'s avatar')
        .addAttachmentOption(option => option.setName('avatar').setDescription('The avatar to set').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    async execute(interaction) {
        if (!owner_ids.includes(interaction.user.id)) {
            return interaction.reply({ content: 'You are not the bot owner', ephemeral: true });
        }
        const avatar = interaction.options.getAttachment('avatar');
        interaction.client.user.setAvatar(avatar.url);
        const embed = new EmbedBuilder()
            .setTitle('Avatar set to')
            .setImage(avatar.url)
            .setColor('#ffff00')
            .setTimestamp();
        interaction.reply({ embeds: [embed] });
    }
}