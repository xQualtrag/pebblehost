const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('removerole')
        .setDescription('Removes a role from a user')
        .addUserOption(option => option.setName('user').setDescription('The user to remove the role from').setRequired(true))
        .addRoleOption(option => option.setName('role').setDescription('The role to remove from the user').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles | PermissionFlagsBits.ManageGuild | PermissionFlagsBits.BanMembers ),
    async execute(interaction) {
        const user = interaction.options.getUser('user');
        const member = interaction.guild.members.cache.get(user.id);
        const role = interaction.options.getRole('role');
        if (member.roles.highest.position >= interaction.member.roles.highest.position) {
            return interaction.reply('The user role is higher than or equal to yours!');
        }
        if (member.roles.highest.position >= interaction.guild.members.me.roles.highest.position) {
            return interaction.reply('The user role is higher than or equal to mine!');
        }
        if (!member.roles.cache.has(role.id)) {
            return interaction.reply('The user does not have that role!');
        }
        member.roles.remove(role);
        await interaction.reply(`Removed ${role.name} from ${user}`);
    }
}