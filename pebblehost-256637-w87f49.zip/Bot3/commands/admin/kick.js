const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('kick')
        .setDescription('Kicks a user from the server')
        .addUserOption(option => option.setName('user').setDescription('The user to kick').setRequired(true))
        .addStringOption(option => option.setName('reason').setDescription('The reason for the kick').setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers | PermissionFlagsBits.ManageGuild | PermissionFlagsBits.BanMembers),
    async execute(interaction) {
        const user = interaction.options.getUser('user');
        const member = interaction.guild.members.cache.get(user.id);
        const reason = interaction.options.getString('reason');
        const guild = interaction.guild;
        if (member.roles.highest.position >= interaction.member.roles.highest.position) {
            return interaction.reply('The user role is higher than or equal to yours!');
        }
        if (member.roles.highest.position >= interaction.guild.members.me.roles.hightest) {
            return interaction.reply('The user role is higher than or equal to mine!');
        }
        guild.members.kick(member, { reason: reason });
        if (reason) {
            await interaction.reply(`Kicked ${user} for ${reason}`);
        } else {
            await interaction.reply(`Kicked ${user}`);
        }
    }
}