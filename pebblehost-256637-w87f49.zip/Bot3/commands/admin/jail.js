const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const ms = require('ms');
const fs = require('node:fs');
let muted = fs.readFileSync(__dirname + '/../../muted.json', 'utf8');
muted = JSON.parse(muted);
const { muted_role_id } = require('../../config.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('jail')
        .setDescription('Mute a user')
        .addUserOption(option => option.setName('user').setDescription('The user to mute').setRequired(true))
        .addStringOption(option => option.setName('time').setDescription('The time to mute the user for').setRequired(true))
        .addStringOption(option => option.setName('reason').setDescription('The reason for the mute').setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild | PermissionFlagsBits.KickMembers | PermissionFlagsBits.BanMembers),
    async execute(interaction) {
        const user = interaction.options.getUser('user');
        const member = interaction.guild.members.cache.get(user.id);
        let time = interaction.options.getString('time');
        const reason = interaction.options.getString('reason');
        if (member.roles.highest.position >= interaction.member.roles.highest.position) {
            return interaction.reply('The user role is higher than or equal to yours!');
        }
        if (member.roles.highest.position >= interaction.guild.members.me.roles.hightest) {
            return interaction.reply('The user role is higher than or equal to mine!');
        }
        tFormat = ['min', 'hrs', 'd'];
        if (time.includes(tFormat[0]) || time.includes(tFormat[1]) || time.includes(tFormat[2])) {
            time = ms(time);
        } else {
            return interaction.reply('Please enter a valid time! (e.g. 1d, 1hr, 1min)');
        }
        const role = interaction.guild.roles.cache.find(role => role.id === muted_role_id);
        member.roles.add(role);
        const newMuted = {
            id: user.id,
            time: Date.now() + time,
        } 
        muted.push(newMuted);
        fs.writeFileSync(__dirname + '/../../muted.json', JSON.stringify(muted, null, 4));
        if (reason) {
            await interaction.reply(`Muted ${user} for ${mstoTime(time)} with reason : ${reason}`);
        } else {
            await interaction.reply(`Muted ${user} for ${mstoTime(time)}`);
        }
    }
}

function mstoTime(t) {
    let secs = Math.floor(t / 1000);
    let mins = Math.floor(secs / 60);
    let hours = Math.floor(mins / 60);
    let days = Math.floor(hours / 24);
    secs %= 60;
    mins %= 60;
    hours %= 24;
    let time = `${days} days, ${hours} hours, ${mins} minutes, ${secs} seconds`;
    let a = time.split(', ');
    let b = a.filter(x => x.startsWith('0'))
    b.forEach(x => a.splice(a.indexOf(x), 1));
    return a.join(', ');
}  