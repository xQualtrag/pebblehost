const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
let muted = fs.readFileSync(__dirname + '/../../muted.json', 'utf8');
muted = JSON.parse(muted);
const { muted_role_id } = require('../../config.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('unjail')
        .setDescription('Unmute a user')
        .addUserOption(option => option.setName('user').setDescription('The user to unmute').setRequired(true)).
        setDefaultMemberPermissions(PermissionFlagsBits.KickMembers | PermissionFlagsBits.BanMembers | PermissionFlagsBits.ManageGuild),
    async execute(interaction) {
        const member = interaction.options.getUser('user');
        let mutedMember = muted.filter(m => m.id === member.id)[0];
        if (!mutedMember && !member.roles.cache.has(muted_role_id)) {
            return interaction.reply('This user is not muted');
        }
        if (member.roles.highest.position >= interaction.member.roles.highest.position) {
            return interaction.reply('The user role is higher than or equal to yours!');
        }
        if (member.roles.highest.position >= interaction.guild.members.me.roles.hightest) {
            return interaction.reply('The user role is higher than or equal to mine!');
        }
        const role = interaction.guild.roles.cache.find(role => role.id === muted_role_id);
        member.roles.remove(role);
        if (mutedMember) {
            muted.splice(muted.indexOf(mutedMember), 1);
            fs.writeFileSync(__dirname + '/../../muted.json', JSON.stringify(muted, null, 4));
        }
    }
}