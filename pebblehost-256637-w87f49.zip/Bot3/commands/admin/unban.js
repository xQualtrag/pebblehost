const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('unban')
        .setDescription('Unbans a user from the server')
        .addStringOption(option => option.setName('user').setDescription('The id of user to unban').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers | PermissionFlagsBits.ManageGuild),
    async execute(interaction) {
        const user = interaction.options.getString('user');
        const bans = await interaction.guild.bans.fetch();
        if (!bans.has(user)) {
            return interaction.reply({ content: 'This user is not banned', ephemeral: true });
        }
        bans.forEach(ban => {
            if (ban.user.id == user) {
                interaction.guild.members.unban(ban.user);
                interaction.reply(`Unbanned **${ban.user.tag}**`);
            }
        });
    }
    
}