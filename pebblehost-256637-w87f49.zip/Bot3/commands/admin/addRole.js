const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('addrole')
        .setDescription('Adds a role to a user')
        .addUserOption(option => option.setName('user').setDescription('The user to add the role to').setRequired(true))
        .addRoleOption(option => option.setName('role').setDescription('The role to add to the user').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles | PermissionFlagsBits.ManageGuild | PermissionFlagsBits.BanMembers ),
    async execute(interaction) {
        const user = interaction.options.getUser('user');
        const member = interaction.guild.members.cache.get(user.id);
        const role = interaction.options.getRole('role');
        if (member.roles.highest.position >= interaction.member.roles.highest.position) {
            return interaction.reply('The user role is higher than or equal to yours!');
        }
        if (member.roles.highest.position >= interaction.guild.members.me.roles.highest.position) {
            return interaction.reply('The user role is higher than or equal to mine!');
        }
        member.roles.add(role);
        await interaction.reply(`Added ${role.name} to ${user}`);
    }
}