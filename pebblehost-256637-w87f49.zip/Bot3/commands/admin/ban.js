const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
    data: new SlashCommandBuilder()
        .setName('ban')
        .setDescription('Bans a user from the server')
        .addUserOption(option => option.setName('user').setDescription('The user to ban').setRequired(true))
        .addStringOption(option => option.setName('reason').setDescription('The reason for the ban').setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers | PermissionFlagsBits.ManageGuild),
    async execute(interaction) {
        const user = interaction.options.getUser('user');
        const member = interaction.guild.members.cache.get(user.id);
        const reason = interaction.options.getString('reason');
        const guild = interaction.guild;
        if (member.roles.highest.position >= interaction.member.roles.highest.position) {
            return interaction.reply('The user role is higher than or equal to yours!');
        }
        if (member.roles.highest.position >= interaction.guild.members.me.roles.hightest) {
            return interaction.reply('The user role is higher than or equal to mine!');
        }
        guild.members.ban(member, { reason: reason });
        if (reason) {
            await interaction.reply(`Banned ${member} for ${reason}`);
        } else {
            await interaction.reply(`Banned ${member}`);
        }
    }
}