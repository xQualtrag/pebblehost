const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('purge')
        .setDescription('Delete mass messages from a channel')
        .addChannelOption(option => option.setName('channel').setDescription('The channel to delete messaged from').setRequired(true))
        .addIntegerOption(option => option.setName('amount').setDescription('The amount of messages to delete').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages | PermissionFlagsBits.ManageGuild),
    async execute(interaction) {
        const channel = interaction.options.getChannel('channel');
        const amount = interaction.options.getInteger('amount');
        if (amount > 1000) {
            return interaction.reply('You can only delete up to 1000 messages at a time');
        }
        await channel.bulkDelete(amount);
        interaction.reply(`Deleted ${amount} messages from ${channel}`);
    }
}
